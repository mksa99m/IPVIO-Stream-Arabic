package com.ipvio.stream

// Arabic UI translations. Source strings are the German keys used by the app.
// Placeholders are preserved so dynamic values remain intact.
val DictAr = """
Playlist hinzufügen¦إضافة قائمة تشغيل
Dauert nur ein paar Sekunden.¦لن يستغرق الأمر سوى بضع ثوانٍ.
Aus Zwischenablage einfügen¦لصق من الحافظة
Server (z. B. http://server.tld:8080)¦الخادم (مثال: http://server.tld:8080)
Benutzername¦اسم المستخدم
Passwort¦كلمة المرور
Passwort verbergen¦إخفاء كلمة المرور
Passwort anzeigen¦إظهار كلمة المرور
Backup-Server¦خوادم احتياطية
Hinzufügen¦إضافة
Abbrechen¦إلغاء
Alle¦الكل
Alle anzeigen¦عرض الكل
Speichern¦حفظ
Löschen¦حذف
Bearbeiten¦تعديل
Schließen¦إغلاق
Zurück¦رجوع
Weiter¦التالي
Fertig¦تم
OK¦موافق
Ja¦نعم
Nein¦لا
Suchen¦بحث
Suche¦بحث
Filme¦أفلام
Serien¦مسلسلات
Sender¦قنوات
Live TV¦البث المباشر
Live-TV¦البث المباشر
Favoriten¦المفضلة
Zu Favoriten¦إضافة إلى المفضلة
Meine Liste¦قائمتي
Kategorien¦التصنيفات
Einstellungen¦الإعدادات
Allgemein¦عام
Sprache¦اللغة
Sprache der App¦لغة التطبيق
Automatisch (Gerät)¦تلقائي (لغة الجهاز)
Uhrzeit¦الوقت
Zeitformat¦تنسيق الوقت
Zeitzone¦المنطقة الزمنية
Start¦البدء
Startseite¦الصفحة الرئيسية
Bedienung¦التحكم
Wiedergabe¦التشغيل
Player¦المشغل
Ton¦الصوت
Bild¦الصورة
Untertitel¦الترجمة
Qualität¦الجودة
Auflösung¦الدقة
Laden …¦جارٍ التحميل…
Wird geladen …¦جارٍ التحميل…
Bitte warten …¦يرجى الانتظار…
Erneut versuchen¦إعادة المحاولة
Aktualisieren¦تحديث
Nach Updates suchen¦البحث عن تحديثات
Keine Treffer¦لا توجد نتائج
Keine Sender¦لا توجد قنوات
Noch keine Sender¦لا توجد قنوات حتى الآن
Keine Filme¦لا توجد أفلام
Keine Serien¦لا توجد مسلسلات
Verlauf löschen¦مسح السجل
Letzte Suchanfragen¦عمليات البحث الأخيرة
Im Trend¦الرائج
Top bewertet¦الأعلى تقييماً
Neu¦جديد
Neueste¦الأحدث
Heute¦اليوم
Gestern¦أمس
Morgen¦غداً
Woche¦أسبوع
Monat¦شهر
Jahr¦سنة
Datum¦التاريخ
Zeit¦الوقت
Name¦الاسم
Titel¦العنوان
Beschreibung¦الوصف
Informationen¦معلومات
Details¦التفاصيل
Mehr¦المزيد
Weniger¦أقل
Zurücksetzen¦إعادة ضبط
Alles zurücksetzen¦إعادة ضبط الكل
Übernehmen¦تطبيق
Anwenden¦تطبيق
Abspielen¦تشغيل
Pause¦إيقاف مؤقت
Fortsetzen¦متابعة
Stopp¦إيقاف
Stoppen¦إيقاف
Lautstärke¦مستوى الصوت
Stumm¦كتم الصوت
Vollbild¦ملء الشاشة
Bildschirm anpassen¦ضبط الشاشة
Favorit entfernen¦إزالة من المفضلة
Zuletzt angesehen¦شوهد مؤخراً
Weiter ansehen¦متابعة المشاهدة
Folge¦حلقة
Staffel¦موسم
Staffeln¦مواسم
Film¦فيلم
Serie¦مسلسل
Kanal¦قناة
TV-Programm¦دليل البرامج
Programm¦البرنامج
Jetzt¦الآن
Als Nächstes¦التالي
Keine Programmdaten¦لا تتوفر بيانات للبرنامج
Verbindung fehlgeschlagen¦فشل الاتصال
Keine Verbindung¦لا يوجد اتصال
Internetverbindung prüfen¦تحقق من اتصال الإنترنت
Fehler¦خطأ
Erfolgreich¦تم بنجاح
Gespeichert¦تم الحفظ
Gelöscht¦تم الحذف
Importieren¦استيراد
Exportieren¦تصدير
Playlist importieren¦استيراد قائمة تشغيل
Playlist entfernen¦إزالة قائمة التشغيل
Playlist bearbeiten¦تعديل قائمة التشغيل
Playlist¦قائمة التشغيل
Playlists¦قوائم التشغيل
Profil¦الملف الشخصي
Profile¦الملفات الشخصية
PIN¦رمز PIN
Kindersicherung¦الرقابة الأبوية
Aktivieren¦تفعيل
Deaktivieren¦إلغاء التفعيل
Ein¦تشغيل
Aus¦إيقاف
Einblenden¦إظهار
Ausblenden¦إخفاء
Automatisch¦تلقائي
Manuell¦يدوي
System¦النظام
Sprache der Inhalte¦لغات المحتوى
Alle an¦تفعيل الكل
Alle aus¦إيقاف الكل
Übernehmen und laden¦تطبيق وتحميل
Verwerfen¦تجاهل
Aufnahmen¦التسجيلات
Suche läuft …¦جارٍ البحث…
Wiedergabe fehlgeschlagen¦فشل التشغيل
Nicht verfügbar¦غير متاح
Unbekannt¦غير معروف
Kostenlos¦مجاني
Abonnement¦اشتراك
Anbieter¦مزوّد الخدمة
Server¦الخادم
Benutzer¦المستخدم
Anmelden¦تسجيل الدخول
Abmelden¦تسجيل الخروج
Konto¦الحساب
Hilfe¦المساعدة
Info¦حول التطبيق
Version¦الإصدار
Beenden¦خروج
Noch einmal Zurück drücken zum Beenden¦اضغط زر الرجوع مرة أخرى للخروج
Die Playlist konnte nicht geladen werden¦تعذّر تحميل قائمة التشغيل
Prüfe die Internetverbindung, die Adresse und die Zugangsdaten.¦تحقق من اتصال الإنترنت والعنوان وبيانات تسجيل الدخول.
Diese Playlist enthält keine Filme oder Serien. Live TV findest du links.¦لا تحتوي قائمة التشغيل هذه على أفلام أو مسلسلات. ستجد البث المباشر في الجانب الأيسر.
Filme, Serien oder Sender suchen…¦ابحث عن أفلام أو مسلسلات أو قنوات…
Cover, Beschreibungen, Bewertungen¦الأغلفة والأوصاف والتقييمات
Schauspieler, Regie, ähnliche Titel¦الممثلون والمخرجون والعناوين المشابهة
"""
